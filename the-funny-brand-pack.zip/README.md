
# The Funny — Brand Asset Pack

## Color Palette (Hex)
**Primary:** #2F45FF  
**Secondary (Near-black):** #111827  
**Accent (Orange):** #FF6B00  
**Background:** #F8FAFC  
**Surface:** #FFFFFF  
**Text:** #0F172A  
**Muted Text:** #6B7280  
**Border:** #E5E7EB

**States**
- Success #10B981
- Warning #F59E0B
- Danger #EF4444
- Info #3B82F6

**Gradients**
- Hero: #2F45FF → #7C3AED
- CTA:  #FF6B00 → #FF3D71

## Typography
- Recommended: Inter / system-ui for UI; DM Sans or Poppins for display headings.
- Button text: 600 weight, all-lowercase or Title Case.

## Accessibility
- Use **#FFFFFF on #2F45FF** (ratio > 8:1).  
- Use **#111827 on #FFFFFF** (ratio > 12:1).  
- Avoid small text on Accent Orange; reserve for icons/badges.

## Usage
- Logos are provided in SVG (horizontal, stacked, and mark).  
- Icons are 24px outline style; feel free to change stroke color to `currentColor` in code.  
- Colors JSON included for direct import.

## Suggested UI Tokens
- Radius: 12px (large cards), 8px (inputs/buttons).  
- Shadow: 0 6px 20px rgba(17,24,39,.08).  
- Spacing scale: 4/8/12/16/24/32.
